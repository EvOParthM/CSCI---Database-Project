package application;

public class Item {

	private String id;
	private Integer quantity;
	private Double price;
	
	public Item(String id, String quantity, String price) {
	  this.id = id;
	  this.quantity = Integer.parseInt(quantity);
	  this.price = Double.parseDouble(price);
	}

	public String getId() {
		return id;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public Double getPrice() {
		return price;
	}
	
	@Override
	public String toString() {
		return "id: " + this.id + " quantity: " + this.quantity + " price: " + this.price;
	}
}
