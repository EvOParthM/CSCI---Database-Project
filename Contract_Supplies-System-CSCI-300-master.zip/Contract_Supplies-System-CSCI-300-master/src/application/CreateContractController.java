package application;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.net.URL;
import java.util.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;

public class CreateContractController implements Initializable {

	private ContractModel contractModel;
	private boolean isSupplierChosen;
	private String supplierId;
	private List<Item> contractDataList;
	@FXML
	private ComboBox<String> supplierComboBox;
	@FXML
	private ComboBox<String> itemComboBox;
	@FXML
	private TextField quantityField;
	@FXML
	private TextField priceField;
	@FXML
	private TextArea contractPreviewArea;
	@FXML
	private Button enterItemButton;
	@FXML
	private Button createContractButton;
	@FXML
	private Hyperlink restartContractLink;
	@FXML 
	private Hyperlink backToHomeLink;
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
	  restartContractLink.visitedProperty().set(false);
	  backToHomeLink.visitedProperty().set(false);
	  contractPreviewArea.setEditable(false);
	  contractDataList = new ArrayList<>();
	  contractModel = new ContractModel();
	  isSupplierChosen = false;
	  supplierId = "";
	  try {
		fillItemComboBox();
		fillSupplierComboBox();
	  } catch (SQLException e) {
		e.printStackTrace();
	  }
	}
	
	public void enterItem() {
	  if(!contractModel.validateContractFields(quantityField.getText(), priceField.getText())) {
	    return;
	  }
      if(!isSupplierChosen) {
	    supplierId = getId(supplierComboBox.getSelectionModel().getSelectedItem());	
	    contractPreviewArea.appendText("Supplier:\n" + supplierComboBox.getSelectionModel().getSelectedItem());
	    isSupplierChosen = true;
	  }
      String itemId = getId(itemComboBox.getSelectionModel().getSelectedItem());
	  Item itemToInsert = new Item(itemId, quantityField.getText(), priceField.getText());
	  if(!isItemAdded(contractDataList, itemToInsert)) {
	    contractDataList.add(itemToInsert);	  
	    contractPreviewArea.appendText("\n\n" + "Item:\n" + itemComboBox.getSelectionModel().getSelectedItem() + "  quantity: " + quantityField.getText() + ", price: $" + priceField.getText());
	  } else {
		  AlertChooser itemExistsAlert = new AlertChooser(AlertType.WARNING, "Item is alerady in the contract");
		  itemExistsAlert.getAlert().showAndWait();
	  }
	}
	
	public void createContract() throws SQLException, IOException {
	  String insertContract = "INSERT INTO contract (date_of_con, supplier_id) VALUES (?,?)";
	  String selectAddedContract = "SELECT MAX(con_id) FROM contract";
	  int contractId = -1;
	  String insertItemContract = "INSERT INTO item_contract (contract_price, contract_amt, item_id, contract_id ) VALUES (?,?,?,?)";
	  
	  try {
	    try(PreparedStatement prepContract = Database.connect().prepareStatement(insertContract)) {
	      SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");
          String dateString = format.format(new Date());
          prepContract.setString(1, dateString);
          prepContract.setInt(2, Integer.parseInt(supplierId));
          prepContract.executeUpdate();
	    }
	  
	    try(PreparedStatement prepSelectContract = Database.connect().prepareStatement(selectAddedContract)) {
	      ResultSet rs = prepSelectContract.executeQuery();
	      contractId = rs.getInt(1);
	    }
	  
	    try(PreparedStatement prepItemContract = Database.connect().prepareStatement(insertItemContract)) {
	      for(Item currentItem : contractDataList) {
	        prepItemContract.setDouble(1, currentItem.getPrice());
	        prepItemContract.setInt(2, currentItem.getQuantity());
	        prepItemContract.setInt(3, Integer.parseInt(currentItem.getId()));
	        prepItemContract.setInt(4, contractId);
	        prepItemContract.executeUpdate();
	      }
	    }
	  } catch(Exception e) {
		  AlertChooser improperContract = new AlertChooser(AlertType.WARNING, "Contract is improper \nmake sure you have chosen a supplier and at least 1 item");
	      improperContract.getAlert().showAndWait();
	      return;
	  }
	  AlertChooser successContract = new AlertChooser(AlertType.INFORMATION, "Contract has been successfully added to the system");
      successContract.getAlert().showAndWait();
      backToHome();
	}
	
	public void restartContract() {
	  isSupplierChosen = false;	
	  contractDataList.clear();
	  contractPreviewArea.setText("");	
	}
	
	public void backToHome() throws IOException {
	  Parent root = FXMLLoader.load(getClass().getResource("/application/MainView.fxml"));
	  backToHomeLink.getScene().setRoot(root);
	}
	
	private boolean isItemAdded(List<Item> itemList, Item itemToInsert) {
	  for(Item currentItem : itemList) {
	    if(currentItem.getId().equals(itemToInsert.getId())) {
	      return true;	
	    }
	  }
	  return false;
	}
	
	private String getId(String selectedItem) {
      String id = "";
	  for(int i = 0; i < selectedItem.length(); i++) {
        if(Character.isDigit(selectedItem.charAt(i))) {
          id += selectedItem.charAt(i);	
        }
        if(selectedItem.charAt(i) == ',') {
          break;	
        }
      }
	  return id;
	}
	
	private void fillItemComboBox() throws SQLException {
	  itemComboBox.getItems().removeAll();	
	  String getItemsStatement = "SELECT * FROM item";
	  try(PreparedStatement itemStatement = Database.connect().prepareStatement(getItemsStatement)) {
	    ResultSet itemRs = itemStatement.executeQuery();
	    while(itemRs.next()) {
	      String currentItem = "id: "+ Integer.toString(itemRs.getInt("item_id")) + ",  name: " + itemRs.getString("name") + "\n" + itemRs.getString("description"); 	
	      itemComboBox.getItems().add(currentItem); 	
	    }
	  }
	  itemComboBox.getSelectionModel().selectFirst();
	}

	private void fillSupplierComboBox() throws SQLException {
	  supplierComboBox.getItems().removeAll();	
	  String getSupplierStatement = "SELECT * FROM supplier";
	  try(PreparedStatement supplierStatement = Database.connect().prepareStatement(getSupplierStatement)) {
	    ResultSet supplierRs = supplierStatement.executeQuery();
		while(supplierRs.next()) {
		  String currentItem = "id: "+ Integer.toString(supplierRs.getInt("sup_id")) + ",  name: " + supplierRs.getString("name") + "\n" + supplierRs.getString("street_addr") + " " + supplierRs.getString("city") + ", " + supplierRs.getString("state") + "," + supplierRs.getString("zipcode"); 	
		  supplierComboBox.getItems().add(currentItem); 	
		}
	  }
	  supplierComboBox.getSelectionModel().selectFirst();	
	}

	
}
