package application;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Hyperlink;

public class MainScreenController implements Initializable {
   
	@FXML
	private Hyperlink enterSupplierLink;
	@FXML
	private Hyperlink enterItemLink;
	@FXML
	private Hyperlink createProjectLink;
	@FXML
	private Hyperlink createContractLink;
	@FXML
	private Hyperlink placeOrderLink;
	@FXML
	private Hyperlink exitLink;
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
	  enterSupplierLink.visitedProperty().set(false);
	  exitLink.visitedProperty().set(false);
	}
	
	public void enterSupplier() throws IOException {
	  Parent root = FXMLLoader.load(getClass().getResource("/application/AddSupplierView.fxml")); 
	  enterSupplierLink.getScene().setRoot(root);
	}
	
	public void enterItem() throws IOException {
	  Parent root = FXMLLoader.load(getClass().getResource("/application/AddItemView.fxml"));
	  enterItemLink.getScene().setRoot(root);
	}
	
	public void createProject() throws IOException {
	  Parent root = FXMLLoader.load(getClass().getResource("/application/CreateProjectView.fxml"));
	  createProjectLink.getScene().setRoot(root);
	}
	
	public void createContract() throws IOException {
	  Parent root = FXMLLoader.load(getClass().getResource("/application/CreateContractView.fxml"));
	  createContractLink.getScene().setRoot(root);
	}
	
	public void placeOrder() throws IOException {
	  Parent root = FXMLLoader.load(getClass().getResource("/application/PlaceOrderView.fxml"));
	  placeOrderLink.getScene().setRoot(root);
	}
	
	public void exitSystem() {
	  System.exit(0);
	}

	
}
