package application;

import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class PlaceOrderController implements Initializable {

	private boolean isContractChosen;
	private boolean isProjectChosen;
	@FXML
	private DatePicker dateRequiredPicker;
	@FXML
	private ComboBox<String> projectComboBox;
	@FXML
	private ComboBox<String> contractComboBox;
	@FXML
	private ComboBox<String> itemComboBox;
	@FXML
	private TextField quantityField;
	@FXML
	private TextArea orderPreviewArea;
	@FXML
	private Button enterItemButton;
	@FXML
	private Button placeOrderButton;
	@FXML
	private Hyperlink backToHomeLink;
	@FXML
	private Hyperlink restartOrderLink;
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
	  backToHomeLink.visitedProperty().set(false);
	  restartOrderLink.visitedProperty().set(false);
	  orderPreviewArea.setEditable(false);
	  isProjectChosen = false;
	  isContractChosen = false;
	  try { 
	    fillProjectComboBox();
	    fillContractComboBox();
	    fillItemComboBox();
	  } catch(SQLException e) {
		  e.printStackTrace();
	  }
	}
	
	public void setItemsByContract() {
	  	
	}
	
	public void backToHome() throws IOException {
	  Parent root = FXMLLoader.load(getClass().getResource("/application/MainView.fxml"));
	  backToHomeLink.getScene().setRoot(root);
	}
	
	private void fillProjectComboBox() throws SQLException {
	  projectComboBox.getItems().clear();
	  String selectProj = "SELECT * FROM Project";
	  try(PreparedStatement prepSelectProj = Database.connect().prepareStatement(selectProj)) {
	    ResultSet projRs = prepSelectProj.executeQuery();
	    while(projRs.next()) {	
	      String currentProj = "id: " + Integer.toString(projRs.getInt("proj_id")) + ", " + projRs.getString("proj_data");
	      projectComboBox.getItems().add(currentProj);
	    }
	  }
	  projectComboBox.getSelectionModel().selectFirst();
	}
	
	private void fillContractComboBox() throws SQLException {
	  contractComboBox.getItems().clear();
	  String selectContract = "SELECT con_id, date_of_con FROM contract";
	  try(PreparedStatement prepSelectCon = Database.connect().prepareStatement(selectContract)) {
	    ResultSet conRs = prepSelectCon.executeQuery();
	    while(conRs.next()) {
	      String currentCon = "id: " + Integer.toString(conRs.getInt("con_id")) + ", " + conRs.getString("date_of_con");
	      contractComboBox.getItems().add(currentCon);
	    }
	  }
	  contractComboBox.getSelectionModel().selectFirst();
	}
	
	private void fillItemComboBox() throws SQLException {
	  itemComboBox.getSelectionModel().selectFirst();
	  int contractId = Integer.parseInt(getId(contractComboBox.getSelectionModel().getSelectedItem()));
	  String selectItemsInContract = "SELECT * FROM item WHERE item.item_id "
	  		                       + "IN (SELECT item_contract.item_id FROM item_contract WHERE item_contract.contract_id=?)";
	  try(PreparedStatement prepSelectItems = Database.connect().prepareStatement(selectItemsInContract)) {
	    prepSelectItems.setInt(1, contractId);
	    ResultSet itemRs = prepSelectItems.executeQuery();
	    while(itemRs.next()) {
	      String currentItem = "id: " + Integer.toString(itemRs.getInt("item_id")) + ", " + "name: " + itemRs.getString("name") + "\n" + itemRs.getString("description");	
	      itemComboBox.getItems().add(currentItem);
	    }
	  }
	  itemComboBox.getSelectionModel().selectFirst();
	}
	
	private String getId(String selectedItem) {
	  String id = "";
	  for(int i = 0; i < selectedItem.length(); i++) {
	    if(Character.isDigit(selectedItem.charAt(i))) {
		  id += selectedItem.charAt(i);
	    }
		if(selectedItem.charAt(i) == ',') {
		  break;
		}
	  }
	  return id;
	}
	
	

}
