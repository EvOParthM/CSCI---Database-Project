package application;

import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.Parent;
import javafx.scene.control.Alert.AlertType;

public class CreateProjectController implements Initializable {

	private ProjectModel projectModel;
	@FXML
	private Label charCountLabel;
	@FXML
	private TextArea projectDataTextArea;
	@FXML
	private Button createProjectButton;
	@FXML
	private Hyperlink backToHomeLink;
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
	  charCountLabel.setText("0");
	  projectModel = new ProjectModel();
	  backToHomeLink.visitedProperty().set(false);
	  projectDataTextArea.setWrapText(true);
	}
	
	public void createProject() throws SQLException, IOException {
	  String insertProject = "INSERT INTO project (proj_data) VALUES (?)";
	  if(!projectModel.validateProject(projectDataTextArea.getText())) {
	    return; 	  
	  }
	  try(PreparedStatement insertStatement = Database.connect().prepareStatement(insertProject)) {
	    insertStatement.setString(1, projectDataTextArea.getText());
	    insertStatement.executeUpdate(); 
	    AlertChooser projectSuccessAlert = new AlertChooser(AlertType.INFORMATION, "The Project has been successfully created");
	    projectSuccessAlert.getAlert().showAndWait();
	  }
	  backToHome();
	}
	
	public void backToHome() throws IOException {
	  Parent root = FXMLLoader.load(getClass().getResource("/application/MainView.fxml"));
	  backToHomeLink.getScene().setRoot(root);
	}
	
	public void projectDataLength() {
	  final int MAX_LENGTH = 256; 
	  projectDataTextArea.textProperty().addListener(new ChangeListener<String>() {
	    @Override
	    public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
	      charCountLabel.setText(Integer.toString(newValue.length()));
		  if(projectDataTextArea.getText().length() > MAX_LENGTH) {
		    String newString = projectDataTextArea.getText().substring(0, MAX_LENGTH);
		    projectDataTextArea.setText(newString);
		  }
	    }
	  });
	}

}
