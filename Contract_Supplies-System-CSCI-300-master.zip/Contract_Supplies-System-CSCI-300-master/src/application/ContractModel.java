package application;

import javafx.scene.control.Alert.AlertType;

public class ContractModel {
	
	public boolean validateContractFields(String quantity, String price) {
	  if(!(isValidQuantity(quantity) && isValidPrice(price))) {
	    return false;	  
	  }
	  return true;
	}

	private boolean isValidPrice(String price) {
	  try {
        Double.parseDouble(price);	
        if(price.charAt(0) == '-' || price.charAt(0) == '0') {
          AlertChooser priceAlert = new AlertChooser(AlertType.WARNING, "Price is invalid it must be a positive decimal number");
      	  priceAlert.getAlert().showAndWait();
        }
      } catch (Exception e) {
    	  AlertChooser priceAlert = new AlertChooser(AlertType.WARNING, "Price is invalid it must be a decimal number");
    	  priceAlert.getAlert().showAndWait();
    	  return false;  
      }
      return true;
	}

	private boolean isValidQuantity(String quantity) {
	  try {
	    Integer.parseInt(quantity);	
	    if(quantity.charAt(0) == '-' || quantity.charAt(0) == '0') {
	      AlertChooser quantityAlert = new AlertChooser(AlertType.WARNING, "Price is invalid it must be a positive integer");
	      quantityAlert.getAlert().showAndWait();
	    }
	  } catch (Exception ex) {
	      AlertChooser quantityAlert = new AlertChooser(AlertType.WARNING, "Quantity is invalid it must be a integer number");
	      quantityAlert.getAlert().showAndWait();
	      return false;  
	  }
	  return true;
	}

}
