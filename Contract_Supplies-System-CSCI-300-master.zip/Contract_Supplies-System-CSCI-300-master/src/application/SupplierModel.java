package application;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javafx.scene.control.Alert.AlertType;

public class SupplierModel {
	
	private static final Pattern VALID_CITY_REGEX = Pattern.compile("^[a-zA-Z]+(?:[\\s-][a-zA-Z]+)*$");
	private static final Pattern VALID_NAME_REGEX = Pattern.compile("^([a-zA-Z0-9 ]*)\\w+$");
	private static final Pattern VALID_ZIPCODE_REGEX = Pattern.compile("^\\d{5}(?:[-\\s]\\d{4})?$");
	private static final Pattern VALID_STREET_ADDRESS_REGEX = Pattern.compile("^\\d+\\s[A-z]+\\s[A-z]+");
	
	public boolean validateSupplierFields(String name, String address, String city, String zipcode) throws SQLException {
	  if(!(isValidName(name) && isValidAddress(address) && isValidCity(city) && isValidZipcode(zipcode))) {
	    return false;	  
	  }
	  return true;
	}
	
	private boolean isValidName(String name) throws SQLException {
	  Matcher nameMatcher = VALID_NAME_REGEX.matcher(name);
	  String query = "SELECT * FROM supplier WHERE name=?";	
	  if(!nameMatcher.find() || name.isEmpty()) {
	    AlertChooser nameAlert = new AlertChooser(AlertType.WARNING, "Name is invalid");
	    nameAlert.getAlert().showAndWait();
	    return false;	  
	  } 
	  try(PreparedStatement selectStatement = Database.connect().prepareStatement(query)) {
	    selectStatement.setString(1, name);
	    ResultSet rs = selectStatement.executeQuery();
	    if(!rs.isClosed()) {
	      AlertChooser nameExistsAlert = new AlertChooser(AlertType.WARNING, "Supplier already exists");
	      nameExistsAlert.getAlert().showAndWait();
	      return false;	
	    }
	  }
	  return true;
	}
	
	private boolean isValidAddress(String address) {
	  Matcher addressMatcher = VALID_STREET_ADDRESS_REGEX.matcher(address);
	  if(!addressMatcher.find() || address.isEmpty()) {
	    AlertChooser addressAlert = new AlertChooser(AlertType.WARNING, "Address is invalid");
	    addressAlert.getAlert().showAndWait();
	    return false;
	  }
	  return true;
	}
	
	private boolean isValidCity(String city) {
	  Matcher addressMatcher = VALID_CITY_REGEX.matcher(city);
	  if (!addressMatcher.find() || city.isEmpty()) {
	    AlertChooser cityAlert = new AlertChooser(AlertType.WARNING, "City is invalid");
		cityAlert.getAlert().showAndWait();
		return false;
	  }
	  return true;
	}
	
	private boolean isValidZipcode(String zipcode) {
	  Matcher zipcodeMatcher = VALID_ZIPCODE_REGEX.matcher(zipcode);
	  if(!zipcodeMatcher.find() || zipcode.isEmpty()) {
	    AlertChooser zipcodeAlert = new AlertChooser(AlertType.WARNING, "Zipcode is invalid");
	    zipcodeAlert.getAlert().showAndWait();
	    return false;
	  }
	  return true;
	}
}
