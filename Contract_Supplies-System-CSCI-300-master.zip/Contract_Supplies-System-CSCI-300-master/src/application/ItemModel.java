package application;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javafx.scene.control.Alert.AlertType;

public class ItemModel {

	private static final Pattern VALID_NAME_REGEX = Pattern.compile("^([a-zA-Z ,:]*)\\w+.$");
	
	public boolean validateItemFields(String name, String description) throws SQLException {
	  if(!((isValidName(name)) && isValidDescription(description))) {
	    return false;	  
	  }
	  return true;
	}
	
	public boolean isValidName(String name) throws SQLException {
	  Matcher nameMatcher = VALID_NAME_REGEX.matcher(name);
	  if(!nameMatcher.find() || name.isEmpty()) {
	    AlertChooser nameAlert = new AlertChooser(AlertType.WARNING, "Name is invalid");
		nameAlert.getAlert().showAndWait();	  
		return false;
	  }
	  return true;
	}
	
	public boolean isValidDescription(String description) throws SQLException {
	  String query = "SELECT description FROM item WHERE description=?";
	  Matcher descriptionMatcher = VALID_NAME_REGEX.matcher(description);
	  if((!descriptionMatcher.find() || description.isEmpty())) {
		AlertChooser invalidDescription = new AlertChooser(AlertType.WARNING, "Description is invalid");
		invalidDescription.getAlert().showAndWait();
	    return false;	  
	  }
	  try(PreparedStatement selectItemName = Database.connect().prepareStatement(query)) {
	    selectItemName.setString(1, description);
		ResultSet rs = selectItemName.executeQuery();
		if(!rs.isClosed())  {
		  AlertChooser nameAlert = new AlertChooser(AlertType.WARNING, "Item description is already in the system");
	      nameAlert.getAlert().showAndWait();
		  return false;
		}
	  }
	  return true;
	}
}
