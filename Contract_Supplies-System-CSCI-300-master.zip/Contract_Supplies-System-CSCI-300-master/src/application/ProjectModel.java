package application;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javafx.scene.control.Alert.AlertType;

public class ProjectModel {

	private static final Pattern VALID_PROJECT_DATA_REGEX = Pattern.compile("^([a-zA-Z ,:]*)\\w+.$");
	
	public boolean validateProject(String data) {
	  Matcher dataMatcher = VALID_PROJECT_DATA_REGEX.matcher(data);
	  if(data.isEmpty() || !dataMatcher.find()) {
	    AlertChooser invalidDataAlert = new AlertChooser(AlertType.WARNING, "Project Data is invalid");
	    invalidDataAlert.getAlert().showAndWait();
	    return false;
	  }
	  return true;
	}
	
}
