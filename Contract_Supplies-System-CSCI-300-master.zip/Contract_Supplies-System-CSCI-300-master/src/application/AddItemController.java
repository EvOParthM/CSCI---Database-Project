package application;

import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class AddItemController implements Initializable {

    private ItemModel itemModel;	
	@FXML
	private TextField itemNameField;
	@FXML
	private TextArea itemDescriptionTextArea;
	@FXML
	private Button enterItemButton;
	@FXML
	private Hyperlink backToHomeLink;
	@FXML
	private Label charCountLabel;
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
	  charCountLabel.setText("0");
	  itemModel = new ItemModel();
	  backToHomeLink.visitedProperty().set(false);
	}
	
	public void enterItem() throws SQLException, IOException {
	  String insertItem = "INSERT INTO item (name, description) VALUES (?,?)";
	  if(!itemModel.validateItemFields(itemNameField.getText(), itemDescriptionTextArea.getText())) {
		return;  
	  }
	  try(PreparedStatement insertStatement = Database.connect().prepareStatement(insertItem)) {
	    insertStatement.setString(1, itemNameField.getText());
	    insertStatement.setString(2, itemDescriptionTextArea.getText());
	    insertStatement.executeUpdate();
	    String itemAddedMessage = itemNameField.getText() + " with description of " + itemDescriptionTextArea.getText() + "\nhas been added successfully";
	    AlertChooser itemAddedAlert = new AlertChooser(AlertType.INFORMATION, itemAddedMessage);
	    itemAddedAlert.getAlert().showAndWait();
	  }
	  backToHome();
	}
	
	public void descriptionLength() {
	  int MAX_LENGTH = 20;
	  itemDescriptionTextArea.textProperty().addListener(new ChangeListener<String>() {
		@Override
		public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
	      charCountLabel.setText(Integer.toString(newValue.length()));
	      if(itemDescriptionTextArea.getText().length() > MAX_LENGTH) {
	        String newString = itemDescriptionTextArea.getText().substring(0, MAX_LENGTH);
	        itemDescriptionTextArea.setText(newString);
	      }
		}
	  });	
	}
	
	public void backToHome() throws IOException {
	  Parent root = FXMLLoader.load(getClass().getResource("/application/MainView.fxml"));	
	  backToHomeLink.getScene().setRoot(root);
	}

}
