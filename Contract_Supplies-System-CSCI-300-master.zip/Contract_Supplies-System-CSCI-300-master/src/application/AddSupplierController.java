package application;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.Scanner;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.TextField;

public class AddSupplierController implements Initializable {

	
	private SupplierModel supplierModel;
	@FXML
	private Button submitButton;
	@FXML
	private Hyperlink backToHomeLink;
	@FXML
	private ComboBox<String> stateList;
	@FXML
	private TextField nameField;
	@FXML
	private TextField addressField;
	@FXML
	private TextField cityField;
	@FXML
	private TextField zipcodeField;
	
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
	  backToHomeLink.visitedProperty().set(false);
	  supplierModel = new SupplierModel();
	  fillStateList();
	}
	
	public void enterSupplier() throws SQLException, IOException {
	  String insertSupplier = "INSERT INTO supplier (name, street_addr, city, state, zipcode) VALUES (?,?,?,?,?)";
	  if(!supplierModel.validateSupplierFields(nameField.getText(), addressField.getText(), cityField.getText(), zipcodeField.getText())) {
	    return;	  
	  }
	  try(PreparedStatement insertStatement = Database.connect().prepareStatement(insertSupplier)) {
	    insertStatement.setString(1, nameField.getText());
	    insertStatement.setString(2, addressField.getText());
	    insertStatement.setString(3, cityField.getText());
	    insertStatement.setString(4, stateList.getSelectionModel().getSelectedItem());
	    insertStatement.setString(5, zipcodeField.getText());
	    insertStatement.executeUpdate();
	    String supplierEntry = nameField.getText() + " with address: \n" + addressField.getText() + ", " + cityField.getText() + ", " + stateList.getSelectionModel().getSelectedItem() + ", " + zipcodeField.getText() + " \nhas been added.";
	    AlertChooser supplierInsertAlert = new AlertChooser(AlertType.INFORMATION, supplierEntry);
	    supplierInsertAlert.getAlert().showAndWait();
	  }
	  backToHome();
	}
	
	public void backToHome() throws IOException {
	  Parent root = FXMLLoader.load(getClass().getResource("/application/MainView.fxml")); 
	  backToHomeLink.getScene().setRoot(root);	
	}


	private void fillStateList() {
	  stateList.getItems().removeAll(stateList.getItems());
	  File file = new File("All50States");
	  try(Scanner fileData = new Scanner(file);) {
	    while(fileData.hasNext()) {
		  String state = fileData.nextLine();
		  stateList.getItems().add(state);
	    }
	  } catch(FileNotFoundException e) {
		  e.printStackTrace(); 
	  }
	  stateList.getSelectionModel().selectFirst();	
	}

}
