package application;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;

public class AlertChooser {

	Alert alert;
	AlertType alertType;
	String message;
	
	public AlertChooser(AlertType alertType, String message) {
	  this.alertType = alertType;
	  this.message = message;
	  if(this.alertType == AlertType.WARNING) {
	    createWarningAlert();	  
	  } 
	  if(this.alertType == AlertType.CONFIRMATION) {
		createConfirmationAlert();  
	  }
	  if(this.alertType == AlertType.ERROR) {
		createErrorAlert();  
	  }
	  if(this.alertType == AlertType.INFORMATION) {
	    createInformationAlert();	  
	  }
	}

	private void createWarningAlert() {
	  alert = new Alert(AlertType.WARNING);
	  alert.setHeaderText("Warning");
	  alert.setContentText(message);
	}
	
	private void createConfirmationAlert() {
	  alert = new Alert(AlertType.CONFIRMATION);
	  alert.setHeaderText(message);
	  alert.setContentText("Choose your option:");
	  alert.getButtonTypes().addAll(ButtonType.YES, ButtonType.NO);
	}
    
	private void createErrorAlert() {
	  alert = new Alert(AlertType.ERROR);
	  alert.setHeaderText("Error");
	  alert.setContentText(message);
	}
	
    private void createInformationAlert() {
	  alert = new Alert(AlertType.INFORMATION);
	  alert.setHeaderText("Information");
	  alert.setContentText(message);
	}


	public Alert getAlert() {
	  if(this.alert != null) {
	    return this.alert;	  
	  }
	  return null;
	}

}
